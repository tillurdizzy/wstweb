import { ApplicationConfig } from '@angular/core';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { providePrimeNG } from 'primeng/config';
import Aura from "@primeng/themes/aura";
import { definePreset } from "@primeng/themes";

export const MyPreset = definePreset(Aura, {
    primitive: {
        borderRadius: {
            none: "0",
            xs: "2px",
            sm: "4px",
            md: "6px",
            lg: "8px",
            xl: "12px"
        },
        emerald: {
            50: "#f7faf9",
            100: "#d9e7e2",
            200: "#bad4cb",
            300: "#9cc1b5",
            400: "#7dae9e",
            500: "#5f9b87",
            600: "#518473",
            700: "#436d5f",
            800: "#34554a",
            900: "#263e36",
            950: "#182722"
        },
        green: {
            50: "#f0fdf4",
            100: "#dcfce7",
            200: "#bbf7d0",
            300: "#86efac",
            400: "#4ade80",
            500: "#22c55e",
            600: "#16a34a",
            700: "#15803d",
            800: "#166534",
            900: "#14532d",
            950: "#052e16"
        },
        lime: {
            50: "#fcfafa",
            100: "#eee9e5",
            200: "#e1d7d1",
            300: "#d4c6bd",
            400: "#c6b4a8",
            500: "#b9a394",
            600: "#9d8b7e",
            700: "#827268",
            800: "#665a51",
            900: "#4a413b",
            950: "#2e2925"
        },
        red: {
            50: "#fef2f2",
            100: "#fee2e2",
            200: "#fecaca",
            300: "#fca5a5",
            400: "#f87171",
            500: "#ef4444",
            600: "#dc2626",
            700: "#b91c1c",
            800: "#991b1b",
            900: "#7f1d1d",
            950: "#450a0a"
        },
        orange: {
            50: "#fff7ed",
            100: "#ffedd5",
            200: "#fed7aa",
            300: "#fdba74",
            400: "#fb923c",
            500: "#f97316",
            600: "#ea580c",
            700: "#c2410c",
            800: "#9a3412",
            900: "#7c2d12",
            950: "#431407"
        },
        amber: {
            50: "#fdfcfc",
            100: "#f5f1f2",
            200: "#ede6e7",
            300: "#e4dbdc",
            400: "#dcd0d2",
            500: "#d4c5c7",
            600: "#b4a7a9",
            700: "#948a8b",
            800: "#756c6d",
            900: "#554f50",
            950: "#353132"
        },
        yellow: {
            50: "#fefce8",
            100: "#fef9c3",
            200: "#fef08a",
            300: "#fde047",
            400: "#facc15",
            500: "#eab308",
            600: "#ca8a04",
            700: "#a16207",
            800: "#854d0e",
            900: "#713f12",
            950: "#422006"
        },
        teal: {
            50: "#fdfdfe",
            100: "#f6f5fb",
            200: "#efedf8",
            300: "#e8e4f5",
            400: "#e1dcf2",
            500: "#dad4ef",
            600: "#b9b4cb",
            700: "#9994a7",
            800: "#787583",
            900: "#575560",
            950: "#37353c"
        },
        cyan: {
            50: "#ecfeff",
            100: "#cffafe",
            200: "#a5f3fc",
            300: "#67e8f9",
            400: "#22d3ee",
            500: "#06b6d4",
            600: "#0891b2",
            700: "#0e7490",
            800: "#155e75",
            900: "#164e63",
            950: "#083344"
        },
        sky: {
            50: "#f0f9ff",
            100: "#e0f2fe",
            200: "#bae6fd",
            300: "#7dd3fc",
            400: "#38bdf8",
            500: "#0ea5e9",
            600: "#0284c7",
            700: "#0369a1",
            800: "#075985",
            900: "#0c4a6e",
            950: "#082f49"
        },
        blue: {
            50: "#eff6ff",
            100: "#dbeafe",
            200: "#bfdbfe",
            300: "#93c5fd",
            400: "#60a5fa",
            500: "#3b82f6",
            600: "#2563eb",
            700: "#1d4ed8",
            800: "#1e40af",
            900: "#1e3a8a",
            950: "#172554"
        },
        indigo: {
            50: "#eef2ff",
            100: "#e0e7ff",
            200: "#c7d2fe",
            300: "#a5b4fc",
            400: "#818cf8",
            500: "#6366f1",
            600: "#4f46e5",
            700: "#4338ca",
            800: "#3730a3",
            900: "#312e81",
            950: "#1e1b4b"
        },
        violet: {
            50: "#f5f3ff",
            100: "#ede9fe",
            200: "#ddd6fe",
            300: "#c4b5fd",
            400: "#a78bfa",
            500: "#8b5cf6",
            600: "#7c3aed",
            700: "#6d28d9",
            800: "#5b21b6",
            900: "#4c1d95",
            950: "#2e1065"
        },
        purple: {
            50: "#faf5ff",
            100: "#f3e8ff",
            200: "#e9d5ff",
            300: "#d8b4fe",
            400: "#c084fc",
            500: "#a855f7",
            600: "#9333ea",
            700: "#7e22ce",
            800: "#6b21a8",
            900: "#581c87",
            950: "#3b0764"
        },
        fuchsia: {
            50: "#fdf4ff",
            100: "#fae8ff",
            200: "#f5d0fe",
            300: "#f0abfc",
            400: "#e879f9",
            500: "#d946ef",
            600: "#c026d3",
            700: "#a21caf",
            800: "#86198f",
            900: "#701a75",
            950: "#4a044e"
        },
        pink: {
            50: "#fdf2f8",
            100: "#fce7f3",
            200: "#fbcfe8",
            300: "#f9a8d4",
            400: "#f472b6",
            500: "#ec4899",
            600: "#db2777",
            700: "#be185d",
            800: "#9d174d",
            900: "#831843",
            950: "#500724"
        },
        rose: {
            50: "#fff1f2",
            100: "#ffe4e6",
            200: "#fecdd3",
            300: "#fda4af",
            400: "#fb7185",
            500: "#f43f5e",
            600: "#e11d48",
            700: "#be123c",
            800: "#9f1239",
            900: "#881337",
            950: "#4c0519"
        },
        slate: {
            50: "#f8fafc",
            100: "#f1f5f9",
            200: "#e2e8f0",
            300: "#cbd5e1",
            400: "#94a3b8",
            500: "#64748b",
            600: "#475569",
            700: "#334155",
            800: "#1e293b",
            900: "#0f172a",
            950: "#020617"
        },
        gray: {
            50: "#f9fafb",
            100: "#f3f4f6",
            200: "#e5e7eb",
            300: "#d1d5db",
            400: "#9ca3af",
            500: "#6b7280",
            600: "#4b5563",
            700: "#374151",
            800: "#1f2937",
            900: "#111827",
            950: "#030712"
        },
        zinc: {
            50: "#fafafa",
            100: "#f4f4f5",
            200: "#e4e4e7",
            300: "#d4d4d8",
            400: "#a1a1aa",
            500: "#71717a",
            600: "#52525b",
            700: "#3f3f46",
            800: "#27272a",
            900: "#18181b",
            950: "#09090b"
        },
        neutral: {
            50: "#fafafa",
            100: "#f5f5f5",
            200: "#e5e5e5",
            300: "#d4d4d4",
            400: "#a3a3a3",
            500: "#737373",
            600: "#525252",
            700: "#404040",
            800: "#262626",
            900: "#171717",
            950: "#0a0a0a"
        },
        stone: {
            50: "#fafaf9",
            100: "#f5f5f4",
            200: "#e7e5e4",
            300: "#d6d3d1",
            400: "#a8a29e",
            500: "#78716c",
            600: "#57534e",
            700: "#44403c",
            800: "#292524",
            900: "#1c1917",
            950: "#0c0a09"
        }
    },
    semantic: {
        transitionDuration: "0.2s",
        focusRing: {
            width: "1px",
            style: "solid",
            color: "{primary.color}",
            offset: "2px",
            shadow: "none"
        },
        disabledOpacity: "0.6",
        iconSize: "1rem",
        anchorGutter: "2px",
        primary: {
            50: "#f7f8f8",
            100: "#d7dbdb",
            200: "#b7bfbf",
            300: "#97a3a3",
            400: "#788686",
            500: "#586a6a",
            600: "#4b5a5a",
            700: "#3e4a4a",
            800: "#303a3a",
            900: "#232a2a",
            950: "#161b1b"
        },
        formField: {
            paddingX: "0.75rem",
            paddingY: "0.5rem",
            sm: {
                fontSize: "0.875rem",
                paddingX: "0.625rem",
                paddingY: "0.375rem"
            },
            lg: {
                fontSize: "1.125rem",
                paddingX: "0.875rem",
                paddingY: "0.625rem"
            },
            borderRadius: "{border.radius.md}",
            focusRing: {
                width: "0",
                style: "none",
                color: "transparent",
                offset: "0",
                shadow: "none"
            },
            transitionDuration: "{transition.duration}"
        },
        list: {
            padding: "0.25rem 0.25rem",
            gap: "2px",
            header: {
                padding: "0.5rem 1rem 0.25rem 1rem"
            },
            option: {
                padding: "0.5rem 0.75rem",
                borderRadius: "{border.radius.sm}"
            },
            optionGroup: {
                padding: "0.5rem 0.75rem",
                fontWeight: "600"
            }
        },
        content: {
            borderRadius: "{border.radius.md}"
        },
        mask: {
            transitionDuration: "0.15s"
        },
        navigation: {
            list: {
                padding: "0.25rem 0.25rem",
                gap: "2px"
            },
            item: {
                padding: "0.5rem 0.75rem",
                borderRadius: "{border.radius.sm}",
                gap: "0.5rem"
            },
            submenuLabel: {
                padding: "0.5rem 0.75rem",
                fontWeight: "600"
            },
            submenuIcon: {
                size: "0.875rem"
            }
        },
        overlay: {
            select: {
                borderRadius: "{border.radius.md}",
                shadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -2px rgba(0, 0, 0, 0.1)"
            },
            popover: {
                borderRadius: "{border.radius.md}",
                padding: "0.75rem",
                shadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -2px rgba(0, 0, 0, 0.1)"
            },
            modal: {
                borderRadius: "{border.radius.xl}",
                padding: "1.25rem",
                shadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)"
            },
            navigation: {
                shadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -2px rgba(0, 0, 0, 0.1)"
            }
        },
        colorScheme: {
            light: {
                surface: {
                    0: "#ffffff",
                    50: "#f9f9fa",
                    100: "#e1e4e5",
                    200: "#c9ced0",
                    300: "#b1b8bb",
                    400: "#99a3a7",
                    500: "#818d92",
                    600: "#6e787c",
                    700: "#5a6366",
                    800: "#474e50",
                    900: "#34383a",
                    950: "#202325"
                },
                primary: {
                    color: "{primary.600}",
                    contrastColor: "#777777",
                    hoverColor: "{primary.600}",
                    activeColor: "{primary.700}"
                },
                highlight: {
                    background: "{primary.50}",
                    focusBackground: "{primary.100}",
                    color: "{primary.700}",
                    focusColor: "{primary.800}"
                },
                mask: {
                    background: "rgba(0,0,0,0.4)",
                    color: "{surface.200}"
                },
                formField: {
                    background: "{surface.0}",
                    disabledBackground: "{surface.200}",
                    filledBackground: "{surface.50}",
                    filledHoverBackground: "{surface.50}",
                    filledFocusBackground: "{surface.50}",
                    borderColor: "{surface.300}",
                    hoverBorderColor: "{surface.400}",
                    focusBorderColor: "{primary.color}",
                    invalidBorderColor: "{red.400}",
                    color: "{surface.700}",
                    disabledColor: "{surface.500}",
                    placeholderColor: "{surface.500}",
                    invalidPlaceholderColor: "{red.600}",
                    floatLabelColor: "{surface.500}",
                    floatLabelFocusColor: "{primary.600}",
                    floatLabelActiveColor: "{surface.500}",
                    floatLabelInvalidColor: "{form.field.invalid.placeholder.color}",
                    iconColor: "{surface.400}",
                    shadow: "0 0 #0000, 0 0 #0000, 0 1px 2px 0 rgba(18, 18, 23, 0.05)"
                },
                text: {
                    color: "{surface.700}",
                    hoverColor: "{surface.800}",
                    mutedColor: "{surface.500}",
                    hoverMutedColor: "{surface.600}"
                },
                content: {
                    background: "{surface.50}",
                    hoverBackground: "{surface.100}",
                    borderColor: "{surface.200}",
                    color: "{text.color}",
                    hoverColor: "{text.hover.color}"
                },
                overlay: {
                    select: {
                        background: "{surface.0}",
                        borderColor: "{surface.200}",
                        color: "{text.color}"
                    },
                    popover: {
                        background: "{surface.0}",
                        borderColor: "{surface.200}",
                        color: "{text.color}"
                    },
                    modal: {
                        background: "{surface.0}",
                        borderColor: "{surface.200}",
                        color: "{text.color}"
                    }
                },
                list: {
                    option: {
                        focusBackground: "{surface.100}",
                        selectedBackground: "{highlight.background}",
                        selectedFocusBackground: "{highlight.focus.background}",
                        color: "{text.color}",
                        focusColor: "{text.hover.color}",
                        selectedColor: "{highlight.color}",
                        selectedFocusColor: "{highlight.focus.color}",
                        icon: {
                            color: "{surface.400}",
                            focusColor: "{surface.500}"
                        }
                    },
                    optionGroup: {
                        background: "transparent",
                        color: "{text.muted.color}"
                    }
                },
                navigation: {
                    item: {
                        focusBackground: "{surface.100}",
                        activeBackground: "{surface.100}",
                        color: "{text.color}",
                        focusColor: "{text.hover.color}",
                        activeColor: "{text.hover.color}",
                        icon: {
                            color: "{surface.400}",
                            focusColor: "{surface.500}",
                            activeColor: "{surface.500}"
                        }
                    },
                    submenuLabel: {
                        background: "transparent",
                        color: "{text.muted.color}"
                    },
                    submenuIcon: {
                        color: "{surface.400}",
                        focusColor: "{surface.500}",
                        activeColor: "{surface.500}"
                    }
                }
            },
            dark: {
                surface: {
                    0: "#ffffff",
                    50: "#fafafa",
                    100: "#f4f4f5",
                    200: "#e4e4e7",
                    300: "#d4d4d8",
                    400: "#a1a1aa",
                    500: "#71717a",
                    600: "#52525b",
                    700: "#3f3f46",
                    800: "#27272a",
                    900: "#18181b",
                    950: "#09090b"
                },
                primary: {
                    color: "{primary.400}",
                    contrastColor: "{surface.900}",
                    hoverColor: "{primary.300}",
                    activeColor: "{primary.200}"
                },
                highlight: {
                    background: "color-mix(in srgb, {primary.400}, transparent 84%)",
                    focusBackground: "color-mix(in srgb, {primary.400}, transparent 76%)",
                    color: "rgba(255,255,255,.87)",
                    focusColor: "rgba(255,255,255,.87)"
                },
                mask: {
                    background: "rgba(0,0,0,0.6)",
                    color: "{surface.200}"
                },
                formField: {
                    background: "{surface.950}",
                    disabledBackground: "{surface.700}",
                    filledBackground: "{surface.800}",
                    filledHoverBackground: "{surface.800}",
                    filledFocusBackground: "{surface.800}",
                    borderColor: "{surface.600}",
                    hoverBorderColor: "{surface.500}",
                    focusBorderColor: "{primary.color}",
                    invalidBorderColor: "{red.300}",
                    color: "{surface.0}",
                    disabledColor: "{surface.400}",
                    placeholderColor: "{surface.400}",
                    invalidPlaceholderColor: "{red.400}",
                    floatLabelColor: "{surface.400}",
                    floatLabelFocusColor: "{primary.color}",
                    floatLabelActiveColor: "{surface.400}",
                    floatLabelInvalidColor: "{form.field.invalid.placeholder.color}",
                    iconColor: "{surface.400}",
                    shadow: "0 0 #0000, 0 0 #0000, 0 1px 2px 0 rgba(18, 18, 23, 0.05)"
                },
                text: {
                    color: "{surface.0}",
                    hoverColor: "{surface.0}",
                    mutedColor: "{surface.400}",
                    hoverMutedColor: "{surface.300}"
                },
                content: {
                    background: "{surface.900}",
                    hoverBackground: "{surface.800}",
                    borderColor: "{surface.700}",
                    color: "{text.color}",
                    hoverColor: "{text.hover.color}"
                },
                overlay: {
                    select: {
                        background: "{surface.900}",
                        borderColor: "{surface.700}",
                        color: "{text.color}"
                    },
                    popover: {
                        background: "{surface.900}",
                        borderColor: "{surface.700}",
                        color: "{text.color}"
                    },
                    modal: {
                        background: "{surface.900}",
                        borderColor: "{surface.700}",
                        color: "{text.color}"
                    }
                },
                list: {
                    option: {
                        focusBackground: "{surface.800}",
                        selectedBackground: "{highlight.background}",
                        selectedFocusBackground: "{highlight.focus.background}",
                        color: "{text.color}",
                        focusColor: "{text.hover.color}",
                        selectedColor: "{highlight.color}",
                        selectedFocusColor: "{highlight.focus.color}",
                        icon: {
                            color: "{surface.500}",
                            focusColor: "{surface.400}"
                        }
                    },
                    optionGroup: {
                        background: "transparent",
                        color: "{text.muted.color}"
                    }
                },
                navigation: {
                    item: {
                        focusBackground: "{surface.800}",
                        activeBackground: "{surface.800}",
                        color: "{text.color}",
                        focusColor: "{text.hover.color}",
                        activeColor: "{text.hover.color}",
                        icon: {
                            color: "{surface.500}",
                            focusColor: "{surface.400}",
                            activeColor: "{surface.400}"
                        }
                    },
                    submenuLabel: {
                        background: "transparent",
                        color: "{text.muted.color}"
                    },
                    submenuIcon: {
                        color: "{surface.500}",
                        focusColor: "{surface.400}",
                        activeColor: "{surface.400}"
                    }
                }
            }
        }
    },
    components: {
        badge: {
            root: {
                borderRadius: "{border.radius.md}",
                padding: "0 0.5rem",
                fontSize: "0.75rem",
                fontWeight: "700",
                minWidth: "1.5rem",
                height: "1.5rem"
            },
            dot: {
                size: "0.5rem"
            },
            sm: {
                fontSize: "0.625rem",
                minWidth: "1.25rem",
                height: "1.25rem"
            },
            lg: {
                fontSize: "0.875rem",
                minWidth: "1.75rem",
                height: "1.75rem"
            },
            xl: {
                fontSize: "1rem",
                minWidth: "2rem",
                height: "2rem"
            },
            colorScheme: {
                light: {
                    primary: {
                        background: "{primary.color}",
                        color: "{primary.contrast.color}"
                    },
                    secondary: {
                        background: "{surface.100}",
                        color: "{surface.600}"
                    },
                    success: {
                        background: "{green.500}",
                        color: "{surface.0}"
                    },
                    info: {
                        background: "{sky.500}",
                        color: "{surface.0}"
                    },
                    warn: {
                        background: "{orange.500}",
                        color: "{surface.0}"
                    },
                    danger: {
                        background: "{red.500}",
                        color: "{surface.0}"
                    },
                    contrast: {
                        background: "{surface.950}",
                        color: "{surface.0}"
                    }
                },
                dark: {
                    primary: {
                        background: "{primary.color}",
                        color: "{primary.contrast.color}"
                    },
                    secondary: {
                        background: "{surface.800}",
                        color: "{surface.300}"
                    },
                    success: {
                        background: "{green.400}",
                        color: "{green.950}"
                    },
                    info: {
                        background: "{sky.400}",
                        color: "{sky.950}"
                    },
                    warn: {
                        background: "{orange.400}",
                        color: "{orange.950}"
                    },
                    danger: {
                        background: "{red.400}",
                        color: "{red.950}"
                    },
                    contrast: {
                        background: "{surface.0}",
                        color: "{surface.950}"
                    }
                }
            }
        },
        blockui: {
            root: {
                borderRadius: "{content.border.radius}"
            }
        },
        breadcrumb: {
            root: {
                padding: "1rem",
                background: "{content.background}",
                gap: "0.5rem",
                transitionDuration: "{transition.duration}"
            },
            item: {
                color: "{text.muted.color}",
                hoverColor: "{text.color}",
                borderRadius: "{content.border.radius}",
                gap: "{navigation.item.gap}",
                icon: {
                    color: "{navigation.item.icon.color}",
                    hoverColor: "{navigation.item.icon.focus.color}"
                },
                focusRing: {
                    width: "{focus.ring.width}",
                    style: "{focus.ring.style}",
                    color: "{focus.ring.color}",
                    offset: "{focus.ring.offset}",
                    shadow: "{focus.ring.shadow}"
                }
            },
            separator: {
                color: "{navigation.item.icon.color}"
            }
        },
        button: {
            root: {
                borderRadius: "{form.field.border.radius}",
                roundedBorderRadius: "2rem",
                gap: "0.5rem",
                paddingX: "{form.field.padding.x}",
                paddingY: "{form.field.padding.y}",
                iconOnlyWidth: "2.5rem",
                sm: {
                    fontSize: "{form.field.sm.font.size}",
                    paddingX: "{form.field.sm.padding.x}",
                    paddingY: "{form.field.sm.padding.y}"
                },
                lg: {
                    fontSize: "{form.field.lg.font.size}",
                    paddingX: "{form.field.lg.padding.x}",
                    paddingY: "{form.field.lg.padding.y}"
                },
                label: {
                    fontWeight: "500"
                },
                raisedShadow: "0 3px 1px -2px rgba(0, 0, 0, 0.2), 0 2px 2px 0 rgba(0, 0, 0, 0.14), 0 1px 5px 0 rgba(0, 0, 0, 0.12)",
                focusRing: {
                    width: "{focus.ring.width}",
                    style: "{focus.ring.style}",
                    offset: "{focus.ring.offset}"
                },
                badgeSize: "1rem",
                transitionDuration: "{form.field.transition.duration}",
                width: 'auto', // Allow custom width to be set
            },
            colorScheme: {
                light: {
                    root: {
                        primary: {
                            background: "{primary.color}",
                            hoverBackground: "{primary.hover.color}",
                            activeBackground: "{primary.active.color}",
                            borderColor: "{primary.color}",
                            hoverBorderColor: "{primary.hover.color}",
                            activeBorderColor: "{primary.active.color}",
                            color: "{primary.100}",
                            hoverColor: "{primary.400}",
                            activeColor: "{primary.contrast.color}",
                            focusRing: {
                                color: "{primary.color}",
                                shadow: "none"
                            }
                        },
                        secondary: {
                            background: "{surface.100}",
                            hoverBackground: "{surface.200}",
                            activeBackground: "{surface.300}",
                            borderColor: "{surface.100}",
                            hoverBorderColor: "{surface.200}",
                            activeBorderColor: "{surface.300}",
                            color: "{surface.600}",
                            hoverColor: "{surface.700}",
                            activeColor: "{surface.800}",
                            focusRing: {
                                color: "{surface.600}",
                                shadow: "none"
                            }
                        },
                        info: {
                            background: "{sky.500}",
                            hoverBackground: "{sky.600}",
                            activeBackground: "{sky.700}",
                            borderColor: "{sky.500}",
                            hoverBorderColor: "{sky.600}",
                            activeBorderColor: "{sky.700}",
                            color: "#ffffff",
                            hoverColor: "#ffffff",
                            activeColor: "#ffffff",
                            focusRing: {
                                color: "{sky.500}",
                                shadow: "none"
                            }
                        },
                        success: {
                            background: "{green.500}",
                            hoverBackground: "{green.600}",
                            activeBackground: "{green.700}",
                            borderColor: "{green.500}",
                            hoverBorderColor: "{green.600}",
                            activeBorderColor: "{green.700}",
                            color: "#ffffff",
                            hoverColor: "#ffffff",
                            activeColor: "#ffffff",
                            focusRing: {
                                color: "{green.500}",
                                shadow: "none"
                            }
                        },
                        warn: {
                            background: "{orange.500}",
                            hoverBackground: "{orange.600}",
                            activeBackground: "{orange.700}",
                            borderColor: "{orange.500}",
                            hoverBorderColor: "{orange.600}",
                            activeBorderColor: "{orange.700}",
                            color: "#ffffff",
                            hoverColor: "#ffffff",
                            activeColor: "#ffffff",
                            focusRing: {
                                color: "{orange.500}",
                                shadow: "none"
                            }
                        },
                        help: {
                            background: "{purple.500}",
                            hoverBackground: "{purple.600}",
                            activeBackground: "{purple.700}",
                            borderColor: "{purple.500}",
                            hoverBorderColor: "{purple.600}",
                            activeBorderColor: "{purple.700}",
                            color: "#ffffff",
                            hoverColor: "#ffffff",
                            activeColor: "#ffffff",
                            focusRing: {
                                color: "{purple.500}",
                                shadow: "none"
                            }
                        },
                        danger: {
                            background: "{red.500}",
                            hoverBackground: "{red.600}",
                            activeBackground: "{red.700}",
                            borderColor: "{red.500}",
                            hoverBorderColor: "{red.600}",
                            activeBorderColor: "{red.700}",
                            color: "#ffffff",
                            hoverColor: "#ffffff",
                            activeColor: "#ffffff",
                            focusRing: {
                                color: "{red.500}",
                                shadow: "none"
                            }
                        },
                        contrast: {
                            background: "{surface.950}",
                            hoverBackground: "{surface.900}",
                            activeBackground: "{surface.800}",
                            borderColor: "{surface.950}",
                            hoverBorderColor: "{surface.900}",
                            activeBorderColor: "{surface.800}",
                            color: "{surface.0}",
                            hoverColor: "{surface.0}",
                            activeColor: "{surface.0}",
                            focusRing: {
                                color: "{surface.950}",
                                shadow: "none"
                            }
                        }
                    },
                    outlined: {
                        primary: {
                            hoverBackground: "{primary.50}",
                            activeBackground: "{primary.100}",
                            borderColor: "{primary.200}",
                            color: "{primary.color}"
                        },
                        secondary: {
                            hoverBackground: "{surface.50}",
                            activeBackground: "{surface.100}",
                            borderColor: "{surface.200}",
                            color: "{surface.500}"
                        },
                        success: {
                            hoverBackground: "{green.50}",
                            activeBackground: "{green.100}",
                            borderColor: "{green.200}",
                            color: "{green.500}"
                        },
                        info: {
                            hoverBackground: "{sky.50}",
                            activeBackground: "{sky.100}",
                            borderColor: "{sky.200}",
                            color: "{sky.500}"
                        },
                        warn: {
                            hoverBackground: "{orange.50}",
                            activeBackground: "{orange.100}",
                            borderColor: "{orange.200}",
                            color: "{orange.500}"
                        },
                        help: {
                            hoverBackground: "{purple.50}",
                            activeBackground: "{purple.100}",
                            borderColor: "{purple.200}",
                            color: "{purple.500}"
                        },
                        danger: {
                            hoverBackground: "{red.50}",
                            activeBackground: "{red.100}",
                            borderColor: "{red.200}",
                            color: "{red.500}"
                        },
                        contrast: {
                            hoverBackground: "{surface.50}",
                            activeBackground: "{surface.100}",
                            borderColor: "{surface.700}",
                            color: "{surface.950}"
                        },
                        plain: {
                            hoverBackground: "{surface.50}",
                            activeBackground: "{surface.100}",
                            borderColor: "{surface.200}",
                            color: "{surface.700}"
                        }
                    },
                    text: {
                        primary: {
                            hoverBackground: "{primary.50}",
                            activeBackground: "{primary.100}",
                            color: "{primary.color}"
                        },
                        secondary: {
                            hoverBackground: "{surface.50}",
                            activeBackground: "{surface.100}",
                            color: "{surface.500}"
                        },
                        success: {
                            hoverBackground: "{green.50}",
                            activeBackground: "{green.100}",
                            color: "{green.500}"
                        },
                        info: {
                            hoverBackground: "{sky.50}",
                            activeBackground: "{sky.100}",
                            color: "{sky.500}"
                        },
                        warn: {
                            hoverBackground: "{orange.50}",
                            activeBackground: "{orange.100}",
                            color: "{orange.500}"
                        },
                        help: {
                            hoverBackground: "{purple.50}",
                            activeBackground: "{purple.100}",
                            color: "{purple.500}"
                        },
                        danger: {
                            hoverBackground: "{red.50}",
                            activeBackground: "{red.100}",
                            color: "{red.500}"
                        },
                        contrast: {
                            hoverBackground: "{surface.50}",
                            activeBackground: "{surface.100}",
                            color: "{surface.950}"
                        },
                        plain: {
                            hoverBackground: "{surface.50}",
                            activeBackground: "{surface.100}",
                            color: "{surface.700}"
                        }
                    },
                    link: {
                        color: "{primary.color}",
                        hoverColor: "{primary.color}",
                        activeColor: "{primary.color}"
                    }
                }
            }
        },
        card: {
            root: {
                background: "{lime.300}",
                borderRadius: "{border.radius.xl}",
                color: "{content.color}",
                shadow: "0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px -1px rgba(0, 0, 0, 0.1)"
            },
            body: {
                padding: "1.25rem",
                gap: "0.5rem"
            },
            caption: {
                gap: "0.5rem"
            },
            title: {
                fontSize: "1.25rem",
                fontWeight: "450"
            },
            subtitle: {
                color: "{text.muted.color}"
            }
        },
        cascadeselect: {
            root: {
                background: "{form.field.background}",
                disabledBackground: "{form.field.disabled.background}",
                filledBackground: "{form.field.filled.background}",
                filledHoverBackground: "{form.field.filled.hover.background}",
                filledFocusBackground: "{form.field.filled.focus.background}",
                borderColor: "{form.field.border.color}",
                hoverBorderColor: "{form.field.hover.border.color}",
                focusBorderColor: "{form.field.focus.border.color}",
                invalidBorderColor: "{form.field.invalid.border.color}",
                color: "{form.field.color}",
                disabledColor: "{form.field.disabled.color}",
                placeholderColor: "{form.field.placeholder.color}",
                invalidPlaceholderColor: "{form.field.invalid.placeholder.color}",
                shadow: "{form.field.shadow}",
                paddingX: "{form.field.padding.x}",
                paddingY: "{form.field.padding.y}",
                borderRadius: "{form.field.border.radius}",
                focusRing: {
                    width: "{form.field.focus.ring.width}",
                    style: "{form.field.focus.ring.style}",
                    color: "{form.field.focus.ring.color}",
                    offset: "{form.field.focus.ring.offset}",
                    shadow: "{form.field.focus.ring.shadow}"
                },
                transitionDuration: "{form.field.transition.duration}",
                sm: {
                    fontSize: "{form.field.sm.font.size}",
                    paddingX: "{form.field.sm.padding.x}",
                    paddingY: "{form.field.sm.padding.y}"
                },
                lg: {
                    fontSize: "{form.field.lg.font.size}",
                    paddingX: "{form.field.lg.padding.x}",
                    paddingY: "{form.field.lg.padding.y}"
                }
            },
            dropdown: {
                width: "2.5rem",
                color: "{form.field.icon.color}"
            },
            overlay: {
                background: "{overlay.select.background}",
                borderColor: "{overlay.select.border.color}",
                borderRadius: "{overlay.select.border.radius}",
                color: "{overlay.select.color}",
                shadow: "{overlay.select.shadow}"
            },
            list: {
                padding: "{list.padding}",
                gap: "{list.gap}",
                mobileIndent: "1rem"
            },
            option: {
                focusBackground: "{list.option.focus.background}",
                selectedBackground: "{list.option.selected.background}",
                selectedFocusBackground: "{list.option.selected.focus.background}",
                color: "{list.option.color}",
                focusColor: "{list.option.focus.color}",
                selectedColor: "{list.option.selected.color}",
                selectedFocusColor: "{list.option.selected.focus.color}",
                padding: "{list.option.padding}",
                borderRadius: "{list.option.border.radius}",
                icon: {
                    color: "{list.option.icon.color}",
                    focusColor: "{list.option.icon.focus.color}",
                    size: "0.875rem"
                }
            },
            clearIcon: {
                color: "{form.field.icon.color}"
            }
        },
        checkbox: {
            root: {
                borderRadius: "{border.radius.sm}",
                width: "1.25rem",
                height: "1.25rem",
                background: "{form.field.background}",
                checkedBackground: "{primary.100}",
                checkedHoverBackground: "{primary.hover.color}",
                disabledBackground: "{form.field.disabled.background}",
                filledBackground: "{form.field.filled.background}",
                borderColor: "{form.field.border.color}",
                hoverBorderColor: "{form.field.hover.border.color}",
                focusBorderColor: "{form.field.border.color}",
                checkedBorderColor: "{primary.color}",
                checkedHoverBorderColor: "{primary.hover.color}",
                checkedFocusBorderColor: "{primary.color}",
                checkedDisabledBorderColor: "{form.field.border.color}",
                invalidBorderColor: "{form.field.invalid.border.color}",
                shadow: "{form.field.shadow}",
                focusRing: {
                    width: "{focus.ring.width}",
                    style: "{focus.ring.style}",
                    color: "{focus.ring.color}",
                    offset: "{focus.ring.offset}",
                    shadow: "{focus.ring.shadow}"
                },
                transitionDuration: "{form.field.transition.duration}",
                sm: {
                    width: "1rem",
                    height: "1rem"
                },
                lg: {
                    width: "1.5rem",
                    height: "1.5rem"
                }
            },
            label: {
                color: '#333', // Customize label color globally
              },
            icon: {
                size: "0.875rem",
                color: "{form.field.color}",
                checkedColor: "{primary.800}",
                checkedHoverColor: "{primary.contrast.color}",
                disabledColor: "{form.field.disabled.color}",
                sm: {
                    size: "0.75rem"
                },
                lg: {
                    size: "1rem"
                }
            }
        },
        confirmdialog: {
            icon: {
                size: "2rem",
                color: "{overlay.modal.color}"
            },
            content: {
                gap: "1rem"
            }
        },
        confirmpopup: {
            root: {
                background: "{overlay.popover.background}",
                borderColor: "{overlay.popover.border.color}",
                color: "{overlay.popover.color}",
                borderRadius: "{overlay.popover.border.radius}",
                shadow: "{overlay.popover.shadow}",
                gutter: "10px",
                arrowOffset: "1.25rem"
            },
            content: {
                padding: "{overlay.popover.padding}",
                gap: "1rem"
            },
            icon: {
                size: "1.5rem",
                color: "{overlay.popover.color}"
            },
            footer: {
                gap: "0.5rem",
                padding: "0 {overlay.popover.padding} {overlay.popover.padding} {overlay.popover.padding}"
            }
        },
        datatable: {
            root: {
                transitionDuration: "{transition.duration}"
            },
            header: {
                background: "{content.background}",
                borderColor: "{datatable.border.color}",
                color: "{content.color}",
                borderWidth: "0 0 1px 0",
                padding: "0.75rem 1rem"
            },
            headerCell: {
                background: "{content.background}",
                hoverBackground: "{content.hover.background}",
                selectedBackground: "{highlight.background}",
                borderColor: "{datatable.border.color}",
                color: "{content.color}",
                hoverColor: "{content.hover.color}",
                selectedColor: "{highlight.color}",
                gap: "0.5rem",
                padding: "0.75rem 1rem",
                focusRing: {
                    width: "{focus.ring.width}",
                    style: "{focus.ring.style}",
                    color: "{focus.ring.color}",
                    offset: "-1px",
                    shadow: "{focus.ring.shadow}"
                }
            },
            columnTitle: {
                fontWeight: "600"
            },
            row: {
                background: "{content.background}",
                hoverBackground: "{content.hover.background}",
                selectedBackground: "{highlight.background}",
                color: "{content.color}",
                hoverColor: "{content.hover.color}",
                selectedColor: "{highlight.color}",
                focusRing: {
                    width: "{focus.ring.width}",
                    style: "{focus.ring.style}",
                    color: "{focus.ring.color}",
                    offset: "-1px",
                    shadow: "{focus.ring.shadow}"
                }
            },
            bodyCell: {
                borderColor: "{datatable.border.color}",
                padding: "0.75rem 1rem"
            },
            footerCell: {
                background: "{content.background}",
                borderColor: "{datatable.border.color}",
                color: "{content.color}",
                padding: "0.75rem 1rem"
            },
            columnFooter: {
                fontWeight: "600"
            },
            footer: {
                background: "{content.background}",
                borderColor: "{datatable.border.color}",
                color: "{content.color}",
                borderWidth: "0 0 1px 0",
                padding: "0.75rem 1rem"
            },
            dropPoint: {
                color: "{primary.color}"
            },
            columnResizerWidth: "0.5rem",
            resizeIndicator: {
                width: "1px",
                color: "{primary.color}"
            },
            sortIcon: {
                color: "{text.muted.color}",
                hoverColor: "{text.hover.muted.color}",
                size: "0.875rem"
            },
            loadingIcon: {
                size: "2rem"
            },
            rowToggleButton: {
                hoverBackground: "{content.hover.background}",
                selectedHoverBackground: "{content.background}",
                color: "{text.muted.color}",
                hoverColor: "{text.color}",
                selectedHoverColor: "{primary.color}",
                size: "1.75rem",
                borderRadius: "50%",
                focusRing: {
                    width: "{focus.ring.width}",
                    style: "{focus.ring.style}",
                    color: "{focus.ring.color}",
                    offset: "{focus.ring.offset}",
                    shadow: "{focus.ring.shadow}"
                }
            },
            filter: {
                inlineGap: "0.5rem",
                overlaySelect: {
                    background: "{overlay.select.background}",
                    borderColor: "{overlay.select.border.color}",
                    borderRadius: "{overlay.select.border.radius}",
                    color: "{overlay.select.color}",
                    shadow: "{overlay.select.shadow}"
                },
                overlayPopover: {
                    background: "{overlay.popover.background}",
                    borderColor: "{overlay.popover.border.color}",
                    borderRadius: "{overlay.popover.border.radius}",
                    color: "{overlay.popover.color}",
                    shadow: "{overlay.popover.shadow}",
                    padding: "{overlay.popover.padding}",
                    gap: "0.5rem"
                },
                rule: {
                    borderColor: "{content.border.color}"
                },
                constraintList: {
                    padding: "{list.padding}",
                    gap: "{list.gap}"
                },
                constraint: {
                    focusBackground: "{list.option.focus.background}",
                    selectedBackground: "{list.option.selected.background}",
                    selectedFocusBackground: "{list.option.selected.focus.background}",
                    color: "{list.option.color}",
                    focusColor: "{list.option.focus.color}",
                    selectedColor: "{list.option.selected.color}",
                    selectedFocusColor: "{list.option.selected.focus.color}",
                    separator: {
                        borderColor: "{content.border.color}"
                    },
                    padding: "{list.option.padding}",
                    borderRadius: "{list.option.border.radius}"
                }
            },
            paginatorTop: {
                borderColor: "{datatable.border.color}",
                borderWidth: "0 0 1px 0"
            },
            paginatorBottom: {
                borderColor: "{datatable.border.color}",
                borderWidth: "0 0 1px 0"
            },
            colorScheme: {
                light: {
                    root: {
                        borderColor: "{content.border.color}"
                    },
                    row: {
                        stripedBackground: "{surface.50}"
                    },
                    bodyCell: {
                        selectedBorderColor: "{primary.100}"
                    }
                },
                dark: {
                    root: {
                        borderColor: "{surface.800}"
                    },
                    row: {
                        stripedBackground: "{surface.950}"
                    },
                    bodyCell: {
                        selectedBorderColor: "{primary.900}"
                    }
                }
            }
        },
        dialog: {
            root: {
                background: "{overlay.modal.background}",
                borderColor: "{overlay.modal.border.color}",
                color: "{overlay.modal.color}",
                borderRadius: "{overlay.modal.border.radius}",
                shadow: "{overlay.modal.shadow}"
            },
            header: {
                padding: "{overlay.modal.padding}",
                gap: "0.5rem"
            },
            title: {
                fontSize: "1.25rem",
                fontWeight: "600"
            },
            content: {
                padding: "0 {overlay.modal.padding} {overlay.modal.padding} {overlay.modal.padding}"
            },
            footer: {
                padding: "0 {overlay.modal.padding} {overlay.modal.padding} {overlay.modal.padding}",
                gap: "0.5rem"
            }
        },
        divider: {
            root: {
                borderColor: "{content.border.color}"
            },
            content: {
                background: "{content.background}",
                color: "{text.color}"
            },
            horizontal: {
                margin: "1rem 0",
                padding: "0 1rem",
                content: {
                    padding: "0 0.5rem"
                }
            },
            vertical: {
                margin: "0 1rem",
                padding: "0.5rem 0",
                content: {
                    padding: "0.5rem 0"
                }
            }
        },
        fileupload: {
            root: {
                background: "{content.background}",
                borderColor: "{content.border.color}",
                color: "{content.color}",
                borderRadius: "{content.border.radius}",
                transitionDuration: "{transition.duration}"
            },
            header: {
                background: "transparent",
                color: "{text.color}",
                padding: "1.125rem",
                borderColor: "unset",
                borderWidth: "0",
                borderRadius: "0",
                gap: "0.5rem"
            },
            content: {
                highlightBorderColor: "{primary.color}",
                padding: "0 1.125rem 1.125rem 1.125rem",
                gap: "1rem"
            },
            file: {
                padding: "1rem",
                gap: "1rem",
                borderColor: "{content.border.color}",
                info: {
                    gap: "0.5rem"
                }
            },
            fileList: {
                gap: "0.5rem"
            },
            progressbar: {
                height: "0.25rem"
            },
            basic: {
                gap: "0.5rem"
            }
        },
        iftalabel: {
            root: {
                color: "{form.field.float.label.color}",
                focusColor: "{form.field.float.label.focus.color}",
                invalidColor: "{form.field.float.label.invalid.color}",
                transitionDuration: "0.2s",
                positionX: "{form.field.padding.x}",
                top: "{form.field.padding.y}",
                fontSize: "0.75rem",
                fontWeight: "400"
            },
            input: {
                paddingTop: "1.5rem",
                paddingBottom: "{form.field.padding.y}"
            }
        },
        floatlabel: {
            root: {
                color: "{form.field.float.label.color}",
                focusColor: "{form.field.float.label.focus.color}",
                activeColor: "{form.field.float.label.active.color}",
                invalidColor: "{form.field.float.label.invalid.color}",
                transitionDuration: "0.2s",
                positionX: "{form.field.padding.x}",
                positionY: "{form.field.padding.y}",
                fontWeight: "500",
                active: {
                    fontSize: "0.75rem",
                    fontWeight: "400"
                }
            },
            over: {
                active: {
                    top: "-1.25rem"
                }
            },
            in: {
                input: {
                    paddingTop: "1.5rem",
                    paddingBottom: "{form.field.padding.y}"
                },
                active: {
                    top: "{form.field.padding.y}"
                }
            },
            on: {
                borderRadius: "{border.radius.xs}",
                active: {
                    background: "{form.field.background}",
                    padding: "0 0.125rem"
                }
            }
        },
        iconfield: {
            icon: {
                color: "{form.field.icon.color}"
            }
        },
        image: {
            root: {
                transitionDuration: "{transition.duration}"
            },
            preview: {
                icon: {
                    size: "1.5rem"
                },
                mask: {
                    background: "{mask.background}",
                    color: "{mask.color}"
                }
            },
            toolbar: {
                position: {
                    left: "auto",
                    right: "1rem",
                    top: "1rem",
                    bottom: "auto"
                },
                blur: "8px",
                background: "rgba(255,255,255,0.1)",
                borderColor: "rgba(255,255,255,0.2)",
                borderWidth: "1px",
                borderRadius: "30px",
                padding: ".5rem",
                gap: "0.5rem"
            },
            action: {
                hoverBackground: "rgba(255,255,255,0.1)",
                color: "{surface.50}",
                hoverColor: "{surface.0}",
                size: "3rem",
                iconSize: "1.5rem",
                borderRadius: "50%",
                focusRing: {
                    width: "{focus.ring.width}",
                    style: "{focus.ring.style}",
                    color: "{focus.ring.color}",
                    offset: "{focus.ring.offset}",
                    shadow: "{focus.ring.shadow}"
                }
            }
        },
        imagecompare: {
            handle: {
                size: "15px",
                hoverSize: "30px",
                background: "rgba(255,255,255,0.3)",
                hoverBackground: "rgba(255,255,255,0.3)",
                borderColor: "unset",
                hoverBorderColor: "unset",
                borderWidth: "0",
                borderRadius: "50%",
                transitionDuration: "{transition.duration}",
                focusRing: {
                    width: "{focus.ring.width}",
                    style: "{focus.ring.style}",
                    color: "rgba(255,255,255,0.3)",
                    offset: "{focus.ring.offset}",
                    shadow: "{focus.ring.shadow}"
                }
            }
        },
        inlinemessage: {
            root: {
                padding: "{form.field.padding.y} {form.field.padding.x}",
                borderRadius: "{content.border.radius}",
                gap: "0.5rem"
            },
            text: {
                fontWeight: "500"
            },
            icon: {
                size: "1rem"
            },
            colorScheme: {
                light: {
                    info: {
                        background: "color-mix(in srgb, {blue.50}, transparent 5%)",
                        borderColor: "{blue.200}",
                        color: "{blue.600}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {blue.500}, transparent 96%)"
                    },
                    success: {
                        background: "color-mix(in srgb, {green.50}, transparent 5%)",
                        borderColor: "{green.200}",
                        color: "{green.600}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {green.500}, transparent 96%)"
                    },
                    warn: {
                        background: "color-mix(in srgb,{yellow.50}, transparent 5%)",
                        borderColor: "{yellow.200}",
                        color: "{yellow.600}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {yellow.500}, transparent 96%)"
                    },
                    error: {
                        background: "color-mix(in srgb, {red.50}, transparent 5%)",
                        borderColor: "{red.200}",
                        color: "{red.600}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {red.500}, transparent 96%)"
                    },
                    secondary: {
                        background: "{surface.100}",
                        borderColor: "{surface.200}",
                        color: "{surface.600}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {surface.500}, transparent 96%)"
                    },
                    contrast: {
                        background: "{surface.900}",
                        borderColor: "{surface.950}",
                        color: "{surface.50}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {surface.950}, transparent 96%)"
                    }
                },
                dark: {
                    info: {
                        background: "color-mix(in srgb, {blue.500}, transparent 84%)",
                        borderColor: "color-mix(in srgb, {blue.700}, transparent 64%)",
                        color: "{blue.500}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {blue.500}, transparent 96%)"
                    },
                    success: {
                        background: "color-mix(in srgb, {green.500}, transparent 84%)",
                        borderColor: "color-mix(in srgb, {green.700}, transparent 64%)",
                        color: "{green.500}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {green.500}, transparent 96%)"
                    },
                    warn: {
                        background: "color-mix(in srgb, {yellow.500}, transparent 84%)",
                        borderColor: "color-mix(in srgb, {yellow.700}, transparent 64%)",
                        color: "{yellow.500}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {yellow.500}, transparent 96%)"
                    },
                    error: {
                        background: "color-mix(in srgb, {red.500}, transparent 84%)",
                        borderColor: "color-mix(in srgb, {red.700}, transparent 64%)",
                        color: "{red.500}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {red.500}, transparent 96%)"
                    },
                    secondary: {
                        background: "{surface.800}",
                        borderColor: "{surface.700}",
                        color: "{surface.300}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {surface.500}, transparent 96%)"
                    },
                    contrast: {
                        background: "{surface.0}",
                        borderColor: "{surface.100}",
                        color: "{surface.950}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {surface.950}, transparent 96%)"
                    }
                }
            }
        },
        inplace: {
            root: {
                padding: "{form.field.padding.y} {form.field.padding.x}",
                borderRadius: "{content.border.radius}",
                focusRing: {
                    width: "{focus.ring.width}",
                    style: "{focus.ring.style}",
                    color: "{focus.ring.color}",
                    offset: "{focus.ring.offset}",
                    shadow: "{focus.ring.shadow}"
                },
                transitionDuration: "{transition.duration}"
            },
            display: {
                hoverBackground: "{content.hover.background}",
                hoverColor: "{content.hover.color}"
            }
        },
        inputchips: {
            root: {
                background: "{form.field.background}",
                disabledBackground: "{form.field.disabled.background}",
                filledBackground: "{form.field.filled.background}",
                filledFocusBackground: "{form.field.filled.focus.background}",
                borderColor: "{form.field.border.color}",
                hoverBorderColor: "{form.field.hover.border.color}",
                focusBorderColor: "{form.field.focus.border.color}",
                invalidBorderColor: "{form.field.invalid.border.color}",
                color: "{form.field.color}",
                disabledColor: "{form.field.disabled.color}",
                placeholderColor: "{form.field.placeholder.color}",
                shadow: "{form.field.shadow}",
                paddingX: "{form.field.padding.x}",
                paddingY: "{form.field.padding.y}",
                borderRadius: "{form.field.border.radius}",
                focusRing: {
                    width: "{form.field.focus.ring.width}",
                    style: "{form.field.focus.ring.style}",
                    color: "{form.field.focus.ring.color}",
                    offset: "{form.field.focus.ring.offset}",
                    shadow: "{form.field.focus.ring.shadow}"
                },
                transitionDuration: "{form.field.transition.duration}"
            },
            chip: {
                borderRadius: "{border.radius.sm}"
            },
            colorScheme: {
                light: {
                    chip: {
                        focusBackground: "{surface.200}",
                        color: "{surface.800}"
                    }
                },
                dark: {
                    chip: {
                        focusBackground: "{surface.700}",
                        color: "{surface.0}"
                    }
                }
            }
        },
        inputgroup: {
            addon: {
                background: "{form.field.background}",
                borderColor: "{form.field.border.color}",
                color: "{form.field.icon.color}",
                borderRadius: "{form.field.border.radius}",
                padding: "0.5rem",
                minWidth: "2.5rem"
            }
        },
        inputnumber: {
            root: {
                transitionDuration: "{transition.duration}"
            },
            button: {
                width: "2.5rem",
                borderRadius: "{form.field.border.radius}",
                verticalPadding: "{form.field.padding.y}"
            },
            colorScheme: {
                light: {
                    button: {
                        background: "transparent",
                        hoverBackground: "{surface.100}",
                        activeBackground: "{surface.200}",
                        borderColor: "{form.field.border.color}",
                        hoverBorderColor: "{form.field.border.color}",
                        activeBorderColor: "{form.field.border.color}",
                        color: "{surface.400}",
                        hoverColor: "{surface.500}",
                        activeColor: "{surface.600}"
                    }
                },
                dark: {
                    button: {
                        background: "transparent",
                        hoverBackground: "{surface.800}",
                        activeBackground: "{surface.700}",
                        borderColor: "{form.field.border.color}",
                        hoverBorderColor: "{form.field.border.color}",
                        activeBorderColor: "{form.field.border.color}",
                        color: "{surface.400}",
                        hoverColor: "{surface.300}",
                        activeColor: "{surface.200}"
                    }
                }
            }
        },
        inputotp: {
            root: {
                gap: "0.5rem"
            },
            input: {
                width: "2.5rem",
                sm: {
                    width: "2rem"
                },
                lg: {
                    width: "3rem"
                }
            }
        },
        inputtext: {
            root: {
                background: "{form.field.background}",
                disabledBackground: "{form.field.disabled.background}",
                filledBackground: "{form.field.filled.background}",
                filledHoverBackground: "{form.field.filled.hover.background}",
                filledFocusBackground: "{form.field.filled.focus.background}",
                borderColor: "{form.field.border.color}",
                hoverBorderColor: "{form.field.hover.border.color}",
                focusBorderColor: "{form.field.focus.border.color}",
                invalidBorderColor: "{form.field.invalid.border.color}",
                color: "{form.field.color}",
                disabledColor: "{form.field.disabled.color}",
                placeholderColor: "{form.field.placeholder.color}",
                invalidPlaceholderColor: "{form.field.invalid.placeholder.color}",
                shadow: "{form.field.shadow}",
                paddingX: "{form.field.padding.x}",
                paddingY: "{form.field.padding.y}",
                borderRadius: "{form.field.border.radius}",
                focusRing: {
                    width: "{form.field.focus.ring.width}",
                    style: "{form.field.focus.ring.style}",
                    color: "{form.field.focus.ring.color}",
                    offset: "{form.field.focus.ring.offset}",
                    shadow: "{form.field.focus.ring.shadow}"
                },
                transitionDuration: "{form.field.transition.duration}",
                sm: {
                    fontSize: "{form.field.sm.font.size}",
                    paddingX: "{form.field.sm.padding.x}",
                    paddingY: "{form.field.sm.padding.y}"
                },
                lg: {
                    fontSize: "{form.field.lg.font.size}",
                    paddingX: "{form.field.lg.padding.x}",
                    paddingY: "{form.field.lg.padding.y}"
                }
            }
        },
        listbox: {
            root: {
                background: "{form.field.background}",
                disabledBackground: "{form.field.disabled.background}",
                borderColor: "{form.field.border.color}",
                invalidBorderColor: "{form.field.invalid.border.color}",
                color: "{form.field.color}",
                disabledColor: "{form.field.disabled.color}",
                shadow: "{form.field.shadow}",
                borderRadius: "{form.field.border.radius}",
                transitionDuration: "{form.field.transition.duration}"
            },
            list: {
                padding: "{list.padding}",
                gap: "{list.gap}",
                header: {
                    padding: "{list.header.padding}"
                }
            },
            option: {
                focusBackground: "{list.option.focus.background}",
                selectedBackground: "{list.option.selected.background}",
                selectedFocusBackground: "{list.option.selected.focus.background}",
                color: "{list.option.color}",
                focusColor: "{list.option.focus.color}",
                selectedColor: "{list.option.selected.color}",
                selectedFocusColor: "{list.option.selected.focus.color}",
                padding: "{list.option.padding}",
                borderRadius: "{list.option.border.radius}"
            },
            optionGroup: {
                background: "{list.option.group.background}",
                color: "{list.option.group.color}",
                fontWeight: "{list.option.group.font.weight}",
                padding: "{list.option.group.padding}"
            },
            checkmark: {
                color: "{list.option.color}",
                gutterStart: "-0.375rem",
                gutterEnd: "0.375rem"
            },
            emptyMessage: {
                padding: "{list.option.padding}"
            },
            colorScheme: {
                light: {
                    option: {
                        stripedBackground: "{surface.50}"
                    }
                },
                dark: {
                    option: {
                        stripedBackground: "{surface.900}"
                    }
                }
            }
        },
        menu: {
            root: {
                background: "{content.background}",
                borderColor: "{content.border.color}",
                color: "{content.color}",
                borderRadius: "{content.border.radius}",
                shadow: "{overlay.navigation.shadow}",
                transitionDuration: "{transition.duration}"
            },
            list: {
                padding: "{navigation.list.padding}",
                gap: "{navigation.list.gap}"
            },
            item: {
                focusBackground: "{navigation.item.focus.background}",
                color: "{navigation.item.color}",
                focusColor: "{navigation.item.focus.color}",
                padding: "{navigation.item.padding}",
                borderRadius: "{navigation.item.border.radius}",
                gap: "{navigation.item.gap}",
                icon: {
                    color: "{navigation.item.icon.color}",
                    focusColor: "{navigation.item.icon.focus.color}"
                }
            },
            submenuLabel: {
                padding: "{navigation.submenu.label.padding}",
                fontWeight: "{navigation.submenu.label.font.weight}",
                background: "{navigation.submenu.label.background}",
                color: "{navigation.submenu.label.color}"
            },
            separator: {
                borderColor: "{content.border.color}"
            }
        },
        menubar: {
            root: {
                background: "{content.background}",
                borderColor: "{content.border.color}",
                borderRadius: "{content.border.radius}",
                color: "{content.color}",
                gap: "0.5rem",
                padding: "0.5rem 0.75rem",
                transitionDuration: "{transition.duration}"
            },
            baseItem: {
                borderRadius: "{content.border.radius}",
                padding: "{navigation.item.padding}"
            },
            item: {
                focusBackground: "{navigation.item.focus.background}",
                activeBackground: "{navigation.item.active.background}",
                color: "{navigation.item.color}",
                focusColor: "{navigation.item.focus.color}",
                activeColor: "{navigation.item.active.color}",
                padding: "{navigation.item.padding}",
                borderRadius: "{navigation.item.border.radius}",
                gap: "{navigation.item.gap}",
                icon: {
                    color: "{navigation.item.icon.color}",
                    focusColor: "{navigation.item.icon.focus.color}",
                    activeColor: "{navigation.item.icon.active.color}"
                }
            },
            submenu: {
                padding: "{navigation.list.padding}",
                gap: "{navigation.list.gap}",
                background: "{content.background}",
                borderColor: "{content.border.color}",
                borderRadius: "{content.border.radius}",
                shadow: "{overlay.navigation.shadow}",
                mobileIndent: "1rem",
                icon: {
                    size: "{navigation.submenu.icon.size}",
                    color: "{navigation.submenu.icon.color}",
                    focusColor: "{navigation.submenu.icon.focus.color}",
                    activeColor: "{navigation.submenu.icon.active.color}"
                }
            },
            separator: {
                borderColor: "{content.border.color}"
            },
            mobileButton: {
                borderRadius: "50%",
                size: "1.75rem",
                color: "{text.muted.color}",
                hoverColor: "{text.hover.muted.color}",
                hoverBackground: "{content.hover.background}",
                focusRing: {
                    width: "{focus.ring.width}",
                    style: "{focus.ring.style}",
                    color: "{focus.ring.color}",
                    offset: "{focus.ring.offset}",
                    shadow: "{focus.ring.shadow}"
                }
            }
        },
        message: {
            root: {
                borderRadius: "{content.border.radius}",
                borderWidth: "1px",
                transitionDuration: "{transition.duration}"
            },
            content: {
                padding: "0.5rem 0.75rem",
                gap: "0.5rem",
                sm: {
                    padding: "0.375rem 0.625rem"
                },
                lg: {
                    padding: "0.625rem 0.875rem"
                }
            },
            text: {
                fontSize: "1rem",
                fontWeight: "500",
                sm: {
                    fontSize: "0.875rem"
                },
                lg: {
                    fontSize: "1.125rem"
                }
            },
            icon: {
                size: "1.125rem",
                sm: {
                    size: "1rem"
                },
                lg: {
                    size: "1.25rem"
                }
            },
            closeButton: {
                width: "1.75rem",
                height: "1.75rem",
                borderRadius: "50%",
                focusRing: {
                    width: "{focus.ring.width}",
                    style: "{focus.ring.style}",
                    offset: "{focus.ring.offset}"
                }
            },
            closeIcon: {
                size: "1rem",
                sm: {
                    size: "0.875rem"
                },
                lg: {
                    size: "1.125rem"
                }
            },
            outlined: {
                root: {
                    borderWidth: "1px"
                }
            },
            simple: {
                content: {
                    padding: "0"
                }
            },
            colorScheme: {
                light: {
                    info: {
                        background: "color-mix(in srgb, {blue.50}, transparent 5%)",
                        borderColor: "{blue.200}",
                        color: "{blue.600}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {blue.500}, transparent 96%)",
                        closeButton: {
                            hoverBackground: "{blue.100}",
                            focusRing: {
                                color: "{blue.600}",
                                shadow: "none"
                            }
                        },
                        outlined: {
                            color: "{blue.600}",
                            borderColor: "{blue.600}"
                        },
                        simple: {
                            color: "{blue.600}"
                        }
                    },
                    success: {
                        background: "color-mix(in srgb, {green.50}, transparent 5%)",
                        borderColor: "{green.200}",
                        color: "{green.600}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {green.500}, transparent 96%)",
                        closeButton: {
                            hoverBackground: "{green.100}",
                            focusRing: {
                                color: "{green.600}",
                                shadow: "none"
                            }
                        },
                        outlined: {
                            color: "{green.600}",
                            borderColor: "{green.600}"
                        },
                        simple: {
                            color: "{green.600}"
                        }
                    },
                    warn: {
                        background: "color-mix(in srgb,{yellow.50}, transparent 5%)",
                        borderColor: "{yellow.200}",
                        color: "{yellow.600}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {yellow.500}, transparent 96%)",
                        closeButton: {
                            hoverBackground: "{yellow.100}",
                            focusRing: {
                                color: "{yellow.600}",
                                shadow: "none"
                            }
                        },
                        outlined: {
                            color: "{yellow.600}",
                            borderColor: "{yellow.600}"
                        },
                        simple: {
                            color: "{yellow.600}"
                        }
                    },
                    error: {
                        background: "color-mix(in srgb, {red.50}, transparent 5%)",
                        borderColor: "{red.200}",
                        color: "{red.600}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {red.500}, transparent 96%)",
                        closeButton: {
                            hoverBackground: "{red.100}",
                            focusRing: {
                                color: "{red.600}",
                                shadow: "none"
                            }
                        },
                        outlined: {
                            color: "{red.600}",
                            borderColor: "{red.600}"
                        },
                        simple: {
                            color: "{red.600}"
                        }
                    },
                    secondary: {
                        background: "{surface.100}",
                        borderColor: "{surface.200}",
                        color: "{surface.600}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {surface.500}, transparent 96%)",
                        closeButton: {
                            hoverBackground: "{surface.200}",
                            focusRing: {
                                color: "{surface.600}",
                                shadow: "none"
                            }
                        },
                        outlined: {
                            color: "{surface.500}",
                            borderColor: "{surface.500}"
                        },
                        simple: {
                            color: "{surface.500}"
                        }
                    },
                    contrast: {
                        background: "{surface.900}",
                        borderColor: "{surface.950}",
                        color: "{surface.50}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {surface.950}, transparent 96%)",
                        closeButton: {
                            hoverBackground: "{surface.800}",
                            focusRing: {
                                color: "{surface.50}",
                                shadow: "none"
                            }
                        },
                        outlined: {
                            color: "{surface.950}",
                            borderColor: "{surface.950}"
                        },
                        simple: {
                            color: "{surface.950}"
                        }
                    }
                }
            }
        },
        multiselect: {
            root: {
                background: "{form.field.background}",
                disabledBackground: "{form.field.disabled.background}",
                filledBackground: "{form.field.filled.background}",
                filledHoverBackground: "{form.field.filled.hover.background}",
                filledFocusBackground: "{form.field.filled.focus.background}",
                borderColor: "{form.field.border.color}",
                hoverBorderColor: "{form.field.hover.border.color}",
                focusBorderColor: "{form.field.focus.border.color}",
                invalidBorderColor: "{form.field.invalid.border.color}",
                color: "{form.field.color}",
                disabledColor: "{form.field.disabled.color}",
                placeholderColor: "{form.field.placeholder.color}",
                invalidPlaceholderColor: "{form.field.invalid.placeholder.color}",
                shadow: "{form.field.shadow}",
                paddingX: "{form.field.padding.x}",
                paddingY: "{form.field.padding.y}",
                borderRadius: "{form.field.border.radius}",
                focusRing: {
                    width: "{form.field.focus.ring.width}",
                    style: "{form.field.focus.ring.style}",
                    color: "{form.field.focus.ring.color}",
                    offset: "{form.field.focus.ring.offset}",
                    shadow: "{form.field.focus.ring.shadow}"
                },
                transitionDuration: "{form.field.transition.duration}",
                sm: {
                    fontSize: "{form.field.sm.font.size}",
                    paddingX: "{form.field.sm.padding.x}",
                    paddingY: "{form.field.sm.padding.y}"
                },
                lg: {
                    fontSize: "{form.field.lg.font.size}",
                    paddingX: "{form.field.lg.padding.x}",
                    paddingY: "{form.field.lg.padding.y}"
                }
            },
            dropdown: {
                width: "2.5rem",
                color: "{form.field.icon.color}"
            },
            overlay: {
                background: "{overlay.select.background}",
                borderColor: "{overlay.select.border.color}",
                borderRadius: "{overlay.select.border.radius}",
                color: "{overlay.select.color}",
                shadow: "{overlay.select.shadow}"
            },
            list: {
                padding: "{list.padding}",
                gap: "{list.gap}",
                header: {
                    padding: "{list.header.padding}"
                }
            },
            option: {
                focusBackground: "{list.option.focus.background}",
                selectedBackground: "{list.option.selected.background}",
                selectedFocusBackground: "{list.option.selected.focus.background}",
                color: "{list.option.color}",
                focusColor: "{list.option.focus.color}",
                selectedColor: "{list.option.selected.color}",
                selectedFocusColor: "{list.option.selected.focus.color}",
                padding: "{list.option.padding}",
                borderRadius: "{list.option.border.radius}",
                gap: "0.5rem"
            },
            optionGroup: {
                background: "{list.option.group.background}",
                color: "{list.option.group.color}",
                fontWeight: "{list.option.group.font.weight}",
                padding: "{list.option.group.padding}"
            },
            clearIcon: {
                color: "{form.field.icon.color}"
            },
            chip: {
                borderRadius: "{border.radius.sm}"
            },
            emptyMessage: {
                padding: "{list.option.padding}"
            }
        },
        orderlist: {
            root: {
                gap: "1.125rem"
            },
            controls: {
                gap: "0.5rem"
            }
        },
        overlaybadge: {
            root: {
                outline: {
                    width: "2px",
                    color: "{content.background}"
                }
            }
        },
        popover: {
            root: {
                background: "{overlay.popover.background}",
                borderColor: "{overlay.popover.border.color}",
                color: "{overlay.popover.color}",
                borderRadius: "{overlay.popover.border.radius}",
                shadow: "{overlay.popover.shadow}",
                gutter: "10px",
                arrowOffset: "1.25rem"
            },
            content: {
                padding: "{overlay.popover.padding}"
            }
        },
        paginator: {
            root: {
                padding: "0.5rem 1rem",
                gap: "0.25rem",
                borderRadius: "{content.border.radius}",
                background: "{content.background}",
                color: "{content.color}",
                transitionDuration: "{transition.duration}"
            },
            navButton: {
                background: "transparent",
                hoverBackground: "{content.hover.background}",
                selectedBackground: "{highlight.background}",
                color: "{text.muted.color}",
                hoverColor: "{text.hover.muted.color}",
                selectedColor: "{highlight.color}",
                width: "2.5rem",
                height: "2.5rem",
                borderRadius: "50%",
                focusRing: {
                    width: "{focus.ring.width}",
                    style: "{focus.ring.style}",
                    color: "{focus.ring.color}",
                    offset: "{focus.ring.offset}",
                    shadow: "{focus.ring.shadow}"
                }
            },
            currentPageReport: {
                color: "{text.muted.color}"
            },
            jumpToPageInput: {
                maxWidth: "2.5rem"
            }
        },
        password: {
            meter: {
                background: "{content.border.color}",
                borderRadius: "{content.border.radius}",
                height: ".75rem"
            },
            icon: {
                color: "{form.field.icon.color}"
            },
            overlay: {
                background: "{overlay.popover.background}",
                borderColor: "{overlay.popover.border.color}",
                borderRadius: "{overlay.popover.border.radius}",
                color: "{overlay.popover.color}",
                padding: "{overlay.popover.padding}",
                shadow: "{overlay.popover.shadow}"
            },
            content: {
                gap: "0.5rem"
            },
            colorScheme: {
                light: {
                    strength: {
                        weakBackground: "{red.500}",
                        mediumBackground: "{amber.500}",
                        strongBackground: "{green.500}"
                    }
                },
                dark: {
                    strength: {
                        weakBackground: "{red.400}",
                        mediumBackground: "{amber.400}",
                        strongBackground: "{green.400}"
                    }
                }
            }
        },
        panel: {
            root: {
                background: "{content.background}",
                borderColor: "{content.border.color}",
                color: "{content.color}",
                borderRadius: "{content.border.radius}"
            },
            header: {
                background: "transparent",
                color: "{text.color}",
                padding: "1.125rem",
                borderColor: "{content.border.color}",
                borderWidth: "0",
                borderRadius: "0"
            },
            toggleableHeader: {
                padding: "0.375rem 1.125rem"
            },
            title: {
                fontWeight: "600"
            },
            content: {
                padding: "0 1.125rem 1.125rem 1.125rem"
            },
            footer: {
                padding: "0 1.125rem 1.125rem 1.125rem"
            }
        },
        progressspinner: {
            colorScheme: {
                light: {
                    root: {
                        "color.1": "{red.500}",
                        "color.2": "{blue.500}",
                        "color.3": "{green.500}",
                        "color.4": "{yellow.500}"
                    }
                },
                dark: {
                    root: {
                        "color.1": "{red.400}",
                        "color.2": "{blue.400}",
                        "color.3": "{green.400}",
                        "color.4": "{yellow.400}"
                    }
                }
            }
        },
        radiobutton: {
            root: {
                width: "1.25rem",
                height: "1.25rem",
                background: "{form.field.background}",
                checkedBackground: "{primary.color}",
                checkedHoverBackground: "{primary.hover.color}",
                disabledBackground: "{form.field.disabled.background}",
                filledBackground: "{form.field.filled.background}",
                borderColor: "{form.field.border.color}",
                hoverBorderColor: "{form.field.hover.border.color}",
                focusBorderColor: "{form.field.border.color}",
                checkedBorderColor: "{primary.color}",
                checkedHoverBorderColor: "{primary.hover.color}",
                checkedFocusBorderColor: "{primary.color}",
                checkedDisabledBorderColor: "{form.field.border.color}",
                invalidBorderColor: "{form.field.invalid.border.color}",
                shadow: "{form.field.shadow}",
                focusRing: {
                    width: "{focus.ring.width}",
                    style: "{focus.ring.style}",
                    color: "{focus.ring.color}",
                    offset: "{focus.ring.offset}",
                    shadow: "{focus.ring.shadow}"
                },
                transitionDuration: "{form.field.transition.duration}",
                sm: {
                    width: "1rem",
                    height: "1rem"
                },
                lg: {
                    width: "1.5rem",
                    height: "1.5rem"
                }
            },
            icon: {
                size: "0.75rem",
                checkedColor: "{primary.contrast.color}",
                checkedHoverColor: "{primary.contrast.color}",
                disabledColor: "{form.field.disabled.color}",
                sm: {
                    size: "0.5rem"
                },
                lg: {
                    size: "1rem"
                }
            }
        },
        scrollpanel: {
            root: {
                transitionDuration: "{transition.duration}"
            },
            bar: {
                size: "9px",
                borderRadius: "{border.radius.sm}",
                focusRing: {
                    width: "{focus.ring.width}",
                    style: "{focus.ring.style}",
                    color: "{focus.ring.color}",
                    offset: "{focus.ring.offset}",
                    shadow: "{focus.ring.shadow}"
                }
            },
            colorScheme: {
                light: {
                    bar: {
                        background: "{surface.100}"
                    }
                },
                dark: {
                    bar: {
                        background: "{surface.800}"
                    }
                }
            }
        },
        select: {
            root: {
                background: "{form.field.background}",
                disabledBackground: "{form.field.disabled.background}",
                filledBackground: "{form.field.filled.background}",
                filledHoverBackground: "{form.field.filled.hover.background}",
                filledFocusBackground: "{form.field.filled.focus.background}",
                borderColor: "{form.field.border.color}",
                hoverBorderColor: "{form.field.hover.border.color}",
                focusBorderColor: "{form.field.focus.border.color}",
                invalidBorderColor: "{form.field.invalid.border.color}",
                color: "{form.field.color}",
                disabledColor: "{form.field.disabled.color}",
                placeholderColor: "{form.field.placeholder.color}",
                invalidPlaceholderColor: "{form.field.invalid.placeholder.color}",
                shadow: "{form.field.shadow}",
                paddingX: "{form.field.padding.x}",
                paddingY: "{form.field.padding.y}",
                borderRadius: "{form.field.border.radius}",
                focusRing: {
                    width: "{form.field.focus.ring.width}",
                    style: "{form.field.focus.ring.style}",
                    color: "{form.field.focus.ring.color}",
                    offset: "{form.field.focus.ring.offset}",
                    shadow: "{form.field.focus.ring.shadow}"
                },
                transitionDuration: "{form.field.transition.duration}",
                sm: {
                    fontSize: "{form.field.sm.font.size}",
                    paddingX: "{form.field.sm.padding.x}",
                    paddingY: "{form.field.sm.padding.y}"
                },
                lg: {
                    fontSize: "{form.field.lg.font.size}",
                    paddingX: "{form.field.lg.padding.x}",
                    paddingY: "{form.field.lg.padding.y}"
                }
            },
            dropdown: {
                width: "2.5rem",
                color: "{form.field.icon.color}"
            },
            overlay: {
                background: "{overlay.select.background}",
                borderColor: "{overlay.select.border.color}",
                borderRadius: "{overlay.select.border.radius}",
                color: "{overlay.select.color}",
                shadow: "{overlay.select.shadow}"
            },
            list: {
                padding: "{list.padding}",
                gap: "{list.gap}",
                header: {
                    padding: "{list.header.padding}"
                }
            },
            option: {
                focusBackground: "{list.option.focus.background}",
                selectedBackground: "{list.option.selected.background}",
                selectedFocusBackground: "{list.option.selected.focus.background}",
                color: "{list.option.color}",
                focusColor: "{list.option.focus.color}",
                selectedColor: "{list.option.selected.color}",
                selectedFocusColor: "{list.option.selected.focus.color}",
                padding: "{list.option.padding}",
                borderRadius: "{list.option.border.radius}"
            },
            optionGroup: {
                background: "{list.option.group.background}",
                color: "{list.option.group.color}",
                fontWeight: "{list.option.group.font.weight}",
                padding: "{list.option.group.padding}"
            },
            clearIcon: {
                color: "{form.field.icon.color}"
            },
            checkmark: {
                color: "{list.option.color}",
                gutterStart: "-0.375rem",
                gutterEnd: "0.375rem"
            },
            emptyMessage: {
                padding: "{list.option.padding}"
            }
        },
        selectbutton: {
            root: {
                borderRadius: "{form.field.border.radius}"
            },
            colorScheme: {
                light: {
                    root: {
                        invalidBorderColor: "{form.field.invalid.border.color}"
                    }
                },
                dark: {
                    root: {
                        invalidBorderColor: "{form.field.invalid.border.color}"
                    }
                }
            }
        },
        tabmenu: {
            root: {
                transitionDuration: "{transition.duration}"
            },
            tablist: {
                borderWidth: "0 0 1px 0",
                background: "{content.background}",
                borderColor: "{content.border.color}"
            },
            item: {
                background: "transparent",
                hoverBackground: "transparent",
                activeBackground: "transparent",
                borderWidth: "0 0 1px 0",
                borderColor: "{content.border.color}",
                hoverBorderColor: "{content.border.color}",
                activeBorderColor: "{primary.color}",
                color: "{text.muted.color}",
                hoverColor: "{text.color}",
                activeColor: "{primary.color}",
                padding: "1rem 1.125rem",
                fontWeight: "600",
                margin: "0 0 -1px 0",
                gap: "0.5rem",
                focusRing: {
                    width: "{focus.ring.width}",
                    style: "{focus.ring.style}",
                    color: "{focus.ring.color}",
                    offset: "{focus.ring.offset}",
                    shadow: "{focus.ring.shadow}"
                }
            },
            itemIcon: {
                color: "{text.muted.color}",
                hoverColor: "{text.color}",
                activeColor: "{primary.color}"
            },
            activeBar: {
                height: "1px",
                bottom: "-1px",
                background: "{primary.color}"
            }
        },
        tabs: {
            root: {
                transitionDuration: "{transition.duration}"
            },
            tablist: {
                borderWidth: "0 0 1px 0",
                background: "{content.background}",
                borderColor: "{content.border.color}"
            },
            tab: {
                background: "transparent",
                hoverBackground: "transparent",
                activeBackground: "transparent",
                borderWidth: "0 0 1px 0",
                borderColor: "{content.border.color}",
                hoverBorderColor: "{content.border.color}",
                activeBorderColor: "{primary.color}",
                color: "{text.muted.color}",
                hoverColor: "{text.color}",
                activeColor: "{primary.color}",
                padding: "1rem 1.125rem",
                fontWeight: "600",
                margin: "0 0 -1px 0",
                gap: "0.5rem",
                focusRing: {
                    width: "{focus.ring.width}",
                    style: "{focus.ring.style}",
                    color: "{focus.ring.color}",
                    offset: "-1px",
                    shadow: "{focus.ring.shadow}"
                }
            },
            tabpanel: {
                background: "{content.background}",
                color: "{content.color}",
                padding: "0.875rem 1.125rem 1.125rem 1.125rem",
                focusRing: {
                    width: "{focus.ring.width}",
                    style: "{focus.ring.style}",
                    color: "{focus.ring.color}",
                    offset: "{focus.ring.offset}",
                    shadow: "inset {focus.ring.shadow}"
                }
            },
            navButton: {
                background: "{content.background}",
                color: "{text.muted.color}",
                hoverColor: "{text.color}",
                width: "2.5rem",
                focusRing: {
                    width: "{focus.ring.width}",
                    style: "{focus.ring.style}",
                    color: "{focus.ring.color}",
                    offset: "-1px",
                    shadow: "{focus.ring.shadow}"
                }
            },
            activeBar: {
                height: "1px",
                bottom: "-1px",
                background: "{primary.color}"
            },
            colorScheme: {
                light: {
                    navButton: {
                        shadow: "0px 0px 10px 50px rgba(255, 255, 255, 0.6)"
                    }
                },
                dark: {
                    navButton: {
                        shadow: "0px 0px 10px 50px color-mix(in srgb, {content.background}, transparent 50%)"
                    }
                }
            }
        },
        tabview: {
            root: {
                transitionDuration: "{transition.duration}"
            },
            tabList: {
                background: "{content.background}",
                borderColor: "{content.border.color}"
            },
            tab: {
                borderColor: "{content.border.color}",
                activeBorderColor: "{primary.color}",
                color: "{text.muted.color}",
                hoverColor: "{text.color}",
                activeColor: "{primary.color}"
            },
            tabPanel: {
                background: "{content.background}",
                color: "{content.color}"
            },
            navButton: {
                background: "{content.background}",
                color: "{text.muted.color}",
                hoverColor: "{text.color}"
            },
            colorScheme: {
                light: {
                    navButton: {
                        shadow: "0px 0px 10px 50px rgba(255, 255, 255, 0.6)"
                    }
                },
                dark: {
                    navButton: {
                        shadow: "0px 0px 10px 50px color-mix(in srgb, {content.background}, transparent 50%)"
                    }
                }
            }
        },
        textarea: {
            root: {
                background: "{form.field.background}",
                disabledBackground: "{form.field.disabled.background}",
                filledBackground: "{form.field.filled.background}",
                filledHoverBackground: "{form.field.filled.hover.background}",
                filledFocusBackground: "{form.field.filled.focus.background}",
                borderColor: "{form.field.border.color}",
                hoverBorderColor: "{form.field.hover.border.color}",
                focusBorderColor: "{form.field.focus.border.color}",
                invalidBorderColor: "{form.field.invalid.border.color}",
                color: "{form.field.color}",
                disabledColor: "{form.field.disabled.color}",
                placeholderColor: "{form.field.placeholder.color}",
                invalidPlaceholderColor: "{form.field.invalid.placeholder.color}",
                shadow: "{form.field.shadow}",
                paddingX: "{form.field.padding.x}",
                paddingY: "{form.field.padding.y}",
                borderRadius: "{form.field.border.radius}",
                focusRing: {
                    width: "{form.field.focus.ring.width}",
                    style: "{form.field.focus.ring.style}",
                    color: "{form.field.focus.ring.color}",
                    offset: "{form.field.focus.ring.offset}",
                    shadow: "{form.field.focus.ring.shadow}"
                },
                transitionDuration: "{form.field.transition.duration}",
                sm: {
                    fontSize: "{form.field.sm.font.size}",
                    paddingX: "{form.field.sm.padding.x}",
                    paddingY: "{form.field.sm.padding.y}"
                },
                lg: {
                    fontSize: "{form.field.lg.font.size}",
                    paddingX: "{form.field.lg.padding.x}",
                    paddingY: "{form.field.lg.padding.y}"
                }
            }
        },
        tieredmenu: {
            root: {
                background: "{content.background}",
                borderColor: "{content.border.color}",
                color: "{content.color}",
                borderRadius: "{content.border.radius}",
                shadow: "{overlay.navigation.shadow}",
                transitionDuration: "{transition.duration}"
            },
            list: {
                padding: "{navigation.list.padding}",
                gap: "{navigation.list.gap}"
            },
            item: {
                focusBackground: "{navigation.item.focus.background}",
                activeBackground: "{navigation.item.active.background}",
                color: "{navigation.item.color}",
                focusColor: "{navigation.item.focus.color}",
                activeColor: "{navigation.item.active.color}",
                padding: "{navigation.item.padding}",
                borderRadius: "{navigation.item.border.radius}",
                gap: "{navigation.item.gap}",
                icon: {
                    color: "{navigation.item.icon.color}",
                    focusColor: "{navigation.item.icon.focus.color}",
                    activeColor: "{navigation.item.icon.active.color}"
                }
            },
            submenu: {
                mobileIndent: "1rem"
            },
            submenuIcon: {
                size: "{navigation.submenu.icon.size}",
                color: "{navigation.submenu.icon.color}",
                focusColor: "{navigation.submenu.icon.focus.color}",
                activeColor: "{navigation.submenu.icon.active.color}"
            },
            separator: {
                borderColor: "{content.border.color}"
            }
        },
        tag: {
            root: {
                fontSize: "0.875rem",
                fontWeight: "700",
                padding: "0.25rem 0.5rem",
                gap: "0.25rem",
                borderRadius: "{content.border.radius}",
                roundedBorderRadius: "{border.radius.xl}"
            },
            icon: {
                size: "0.75rem"
            },
            colorScheme: {
                light: {
                    primary: {
                        background: "{primary.100}",
                        color: "{primary.700}"
                    },
                    secondary: {
                        background: "{surface.100}",
                        color: "{surface.600}"
                    },
                    success: {
                        background: "{green.100}",
                        color: "{green.700}"
                    },
                    info: {
                        background: "{sky.100}",
                        color: "{sky.700}"
                    },
                    warn: {
                        background: "{orange.100}",
                        color: "{orange.700}"
                    },
                    danger: {
                        background: "{red.100}",
                        color: "{red.700}"
                    },
                    contrast: {
                        background: "{surface.950}",
                        color: "{surface.0}"
                    }
                },
                dark: {
                    primary: {
                        background: "color-mix(in srgb, {primary.500}, transparent 84%)",
                        color: "{primary.300}"
                    },
                    secondary: {
                        background: "{surface.800}",
                        color: "{surface.300}"
                    },
                    success: {
                        background: "color-mix(in srgb, {green.500}, transparent 84%)",
                        color: "{green.300}"
                    },
                    info: {
                        background: "color-mix(in srgb, {sky.500}, transparent 84%)",
                        color: "{sky.300}"
                    },
                    warn: {
                        background: "color-mix(in srgb, {orange.500}, transparent 84%)",
                        color: "{orange.300}"
                    },
                    danger: {
                        background: "color-mix(in srgb, {red.500}, transparent 84%)",
                        color: "{red.300}"
                    },
                    contrast: {
                        background: "{surface.0}",
                        color: "{surface.950}"
                    }
                }
            }
        },
        toast: {
            root: {
                width: "25rem",
                borderRadius: "{content.border.radius}",
                borderWidth: "1px",
                transitionDuration: "{transition.duration}"
            },
            icon: {
                size: "1.125rem"
            },
            content: {
                padding: "{overlay.popover.padding}",
                gap: "0.5rem"
            },
            text: {
                gap: "0.5rem"
            },
            summary: {
                fontWeight: "500",
                fontSize: "1rem"
            },
            detail: {
                fontWeight: "500",
                fontSize: "0.875rem"
            },
            closeButton: {
                width: "1.75rem",
                height: "1.75rem",
                borderRadius: "50%",
                focusRing: {
                    width: "{focus.ring.width}",
                    style: "{focus.ring.style}",
                    offset: "{focus.ring.offset}"
                }
            },
            closeIcon: {
                size: "1rem"
            },
            colorScheme: {
                light: {
                    blur: "1.5px",
                    info: {
                        background: "color-mix(in srgb, {blue.50}, transparent 5%)",
                        borderColor: "{blue.200}",
                        color: "{blue.600}",
                        detailColor: "{surface.700}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {blue.500}, transparent 96%)",
                        closeButton: {
                            hoverBackground: "{blue.100}",
                            focusRing: {
                                color: "{blue.600}",
                                shadow: "none"
                            }
                        }
                    },
                    success: {
                        background: "color-mix(in srgb, {green.50}, transparent 5%)",
                        borderColor: "{green.200}",
                        color: "{green.600}",
                        detailColor: "{surface.700}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {green.500}, transparent 96%)",
                        closeButton: {
                            hoverBackground: "{green.100}",
                            focusRing: {
                                color: "{green.600}",
                                shadow: "none"
                            }
                        }
                    },
                    warn: {
                        background: "color-mix(in srgb,{yellow.50}, transparent 5%)",
                        borderColor: "{yellow.200}",
                        color: "{yellow.600}",
                        detailColor: "{surface.700}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {yellow.500}, transparent 96%)",
                        closeButton: {
                            hoverBackground: "{yellow.100}",
                            focusRing: {
                                color: "{yellow.600}",
                                shadow: "none"
                            }
                        }
                    },
                    error: {
                        background: "color-mix(in srgb, {red.50}, transparent 5%)",
                        borderColor: "{red.200}",
                        color: "{red.600}",
                        detailColor: "{surface.700}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {red.500}, transparent 96%)",
                        closeButton: {
                            hoverBackground: "{red.100}",
                            focusRing: {
                                color: "{red.600}",
                                shadow: "none"
                            }
                        }
                    },
                    secondary: {
                        background: "{surface.100}",
                        borderColor: "{surface.200}",
                        color: "{surface.600}",
                        detailColor: "{surface.700}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {surface.500}, transparent 96%)",
                        closeButton: {
                            hoverBackground: "{surface.200}",
                            focusRing: {
                                color: "{surface.600}",
                                shadow: "none"
                            }
                        }
                    },
                    contrast: {
                        background: "{surface.900}",
                        borderColor: "{surface.950}",
                        color: "{surface.50}",
                        detailColor: "{surface.0}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {surface.950}, transparent 96%)",
                        closeButton: {
                            hoverBackground: "{surface.800}",
                            focusRing: {
                                color: "{surface.50}",
                                shadow: "none"
                            }
                        }
                    }
                },
                dark: {
                    blur: "10px",
                    info: {
                        background: "color-mix(in srgb, {blue.500}, transparent 84%)",
                        borderColor: "color-mix(in srgb, {blue.700}, transparent 64%)",
                        color: "{blue.500}",
                        detailColor: "{surface.0}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {blue.500}, transparent 96%)",
                        closeButton: {
                            hoverBackground: "rgba(255, 255, 255, 0.05)",
                            focusRing: {
                                color: "{blue.500}",
                                shadow: "none"
                            }
                        }
                    },
                    success: {
                        background: "color-mix(in srgb, {green.500}, transparent 84%)",
                        borderColor: "color-mix(in srgb, {green.700}, transparent 64%)",
                        color: "{green.500}",
                        detailColor: "{surface.0}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {green.500}, transparent 96%)",
                        closeButton: {
                            hoverBackground: "rgba(255, 255, 255, 0.05)",
                            focusRing: {
                                color: "{green.500}",
                                shadow: "none"
                            }
                        }
                    },
                    warn: {
                        background: "color-mix(in srgb, {yellow.500}, transparent 84%)",
                        borderColor: "color-mix(in srgb, {yellow.700}, transparent 64%)",
                        color: "{yellow.500}",
                        detailColor: "{surface.0}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {yellow.500}, transparent 96%)",
                        closeButton: {
                            hoverBackground: "rgba(255, 255, 255, 0.05)",
                            focusRing: {
                                color: "{yellow.500}",
                                shadow: "none"
                            }
                        }
                    },
                    error: {
                        background: "color-mix(in srgb, {red.500}, transparent 84%)",
                        borderColor: "color-mix(in srgb, {red.700}, transparent 64%)",
                        color: "{red.500}",
                        detailColor: "{surface.0}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {red.500}, transparent 96%)",
                        closeButton: {
                            hoverBackground: "rgba(255, 255, 255, 0.05)",
                            focusRing: {
                                color: "{red.500}",
                                shadow: "none"
                            }
                        }
                    },
                    secondary: {
                        background: "{surface.800}",
                        borderColor: "{surface.700}",
                        color: "{surface.300}",
                        detailColor: "{surface.0}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {surface.500}, transparent 96%)",
                        closeButton: {
                            hoverBackground: "{surface.700}",
                            focusRing: {
                                color: "{surface.300}",
                                shadow: "none"
                            }
                        }
                    },
                    contrast: {
                        background: "{surface.0}",
                        borderColor: "{surface.100}",
                        color: "{surface.950}",
                        detailColor: "{surface.950}",
                        shadow: "0px 4px 8px 0px color-mix(in srgb, {surface.950}, transparent 96%)",
                        closeButton: {
                            hoverBackground: "{surface.100}",
                            focusRing: {
                                color: "{surface.950}",
                                shadow: "none"
                            }
                        }
                    }
                }
            }
        },
        toolbar: {
            root: {
                background: "{primary.600}",
                borderColor: "{content.border.color}",
                borderRadius: "{content.border.radius}",
                color: "{slate.100}",
                gap: "0.5rem",
                padding: "0.75rem"
            }
        },
        virtualscroller: {
            loader: {
                mask: {
                    background: "{content.background}",
                    color: "{text.muted.color}"
                },
                icon: {
                    size: "2rem"
                }
            }
        },
        ripple: {
            colorScheme: {
                light: {
                    root: {
                        background: "rgba(0,0,0,0.1)"
                    }
                },
                dark: {
                    root: {
                        background: "rgba(255,255,255,0.3)"
                    }
                }
            }
        }
    }
});

export const appConfig: ApplicationConfig = {
    providers: [
        provideAnimationsAsync(),
        providePrimeNG({
            theme: {
               preset: MyPreset,
            }
        })
    ]
};